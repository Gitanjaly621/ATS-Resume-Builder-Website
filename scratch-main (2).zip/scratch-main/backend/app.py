# where pythonimport json
import json
from datetime import datetime
from bson.objectid import ObjectId
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from pymongo import MongoClient
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'  # Change this to a random secret key in production
app.config['MONGO_URI'] = 'mongodb://localhost:27017/'

# Setup MongoDB
client = MongoClient(app.config['MONGO_URI'])
db = client['resumedb']
users_collection = db['users']
resumes_collection = db['resumes']

# Setup Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

class User(UserMixin):
    def __init__(self, user_data):
        self.id = str(user_data['_id'])
        self.username = user_data.get('username')
        self.email = user_data.get('email')
        self.password_hash = user_data.get('password')

@login_manager.user_loader
def load_user(user_id):
    user_data = users_collection.find_one({"_id": ObjectId(user_id)})
    if user_data:
        return User(user_data)
    return None

# --- Auth Routes ---
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        user_data = users_collection.find_one({"email": email})
        if user_data and check_password_hash(user_data['password'], password):
            user = User(user_data)
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('Login failed. Check your email and password.', 'danger')
            
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        existing_user = users_collection.find_one({"email": email})
        if existing_user:
            flash('Email address already exists', 'warning')
            return redirect(url_for('register'))
            
        hashed_password = generate_password_hash(password)
        new_user = {
            "username": username,
            "email": email,
            "password": hashed_password,
            "created_at": datetime.utcnow()
        }
        users_collection.insert_one(new_user)
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
        
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

# --- Main Routes ---
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('home.html')

@app.route('/dashboard')
@login_required
def dashboard():
    resumes_cursor = resumes_collection.find({"user_id": current_user.id}).sort("updated_at", -1)
    resumes = list(resumes_cursor)
    # Convert ObjectIds to strings for the template
    for r in resumes:
        r['id'] = str(r['_id'])
    return render_template('dashboard.html', resumes=resumes)

@app.route('/builder')
@app.route('/builder/<resume_id>')
@login_required
def builder(resume_id=None):
    return render_template('builder.html', resume_id=resume_id)

# --- API Routes ---
@app.route('/api/resume', methods=['POST'])
@login_required
def save_resume():
    req_data = request.get_json()
    title = req_data.get('title', 'Untitled Resume')
    
    resume_id = req_data.get('id')
    
    # Remove id from req_data to store the rest as payload
    if 'id' in req_data:
        del req_data['id']
        
    if resume_id:
        # Update existing
        result = resumes_collection.update_one(
            {"_id": ObjectId(resume_id), "user_id": current_user.id},
            {"$set": {
                "title": title,
                "data": json.dumps(req_data),
                "updated_at": datetime.utcnow()
            }}
        )
        if result.matched_count > 0:
            return jsonify({'success': True, 'id': resume_id})
        else:
            return jsonify({'success': False, 'message': 'Resume not found or unauthorized'}), 404
            
    # Create new
    new_resume = {
        "user_id": current_user.id,
        "title": title,
        "data": json.dumps(req_data),
        "created_at": datetime.utcnow(),
        "updated_at": datetime.utcnow()
    }
    result = resumes_collection.insert_one(new_resume)
    return jsonify({'success': True, 'id': str(result.inserted_id)})

@app.route('/api/resume/<resume_id>', methods=['GET'])
@login_required
def get_resume(resume_id):
    resume = resumes_collection.find_one({"_id": ObjectId(resume_id), "user_id": current_user.id})
    if not resume:
        return jsonify({'success': False, 'message': 'Not found'}), 404
        
    return jsonify({
        'id': str(resume['_id']),
        'title': resume['title'],
        'data': json.loads(resume['data'])
    })

@app.route('/api/resume/<resume_id>', methods=['DELETE'])
@login_required
def delete_resume(resume_id):
    result = resumes_collection.delete_one({"_id": ObjectId(resume_id), "user_id": current_user.id})
    if result.deleted_count > 0:
        return jsonify({'success': True})
    return jsonify({'success': False, 'message': 'Not found or unauthorized'}), 404

# --- Chatbot API (Placeholder) ---
@app.route('/api/chat', methods=['POST'])
@login_required
def chat():
    data = request.get_json()
    user_msg = data.get('message', '').lower()
    
    # Placeholder logic
    response_msg = "I'm your AI Resume Assistant! Right now I'm in demo mode, but soon I'll help you write impactful summaries and bullet points."
    
    if 'summary' in user_msg:
        response_msg = "Need help with a summary? Try highlighting your years of experience, key skills, and biggest achievements. Example: 'Results-driven Software Engineer with 5+ years of experience in building scalable web apps using Python and React.'"
    elif 'bullet' in user_msg or 'experience' in user_msg:
        response_msg = "For experience bullets, use the STAR method: Situation, Task, Action, Result. Start with an action verb. E.g., 'Spearheaded the migration to MongoDB, reducing query times by 40%.'"
    elif 'skill' in user_msg:
        response_msg = "Make sure to list hard skills relevant to the job description to get past the ATS!"
        
    return jsonify({'response': response_msg})

if __name__ == '__main__':
    app.run(debug=True, port=5000)






from flask import Flask, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app) # Allows your React frontend to talk to this Python backend

# Mock data representing your "New professional designs" section
resume_features = {
    "section_title": "Why Use Our Online Resume Builder",
    "feature_highlight": {
        "title": "New, professional designs",
        "description": "Choose from a wide range of styles for every job level and type. From fun and creative to simple and modern, we offer designs for all types of job seekers.",
        "image_url": "/assets/resume-mockup.png" # Path to your image
    }
}

@app.route('/api/features', methods=['GET'])
def get_features():
    """Returns the content for the features page section."""
    return jsonify(resume_features)

if __name__ == '__main__':
    # Debug mode is on, which matches your 'stat' restarting message
    app.run(debug=True, port=5000)
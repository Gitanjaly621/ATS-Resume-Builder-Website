document.addEventListener('DOMContentLoaded', () => {
    // Setup real-time sync for simple inputs
    const syncInputs = document.querySelectorAll('.sync-input');
    syncInputs.forEach(input => {
        input.addEventListener('input', (e) => {
            const targetId = e.target.getAttribute('data-target');
            const targetEl = document.getElementById(targetId);
            if (targetEl) {
                targetEl.textContent = e.target.value;
            }
        });
    });

    // Load existing resume data if ID is present
    const resumeId = document.getElementById('resume-id').value;
    if (resumeId) {
        loadResumeData(resumeId);
    } else {
        // Add one empty experience and education by default
        addExperience();
        addEducation();
    }
});

// Template switching
function changeTemplate() {
    const selector = document.getElementById('template-style');
    const preview = document.getElementById('resume-preview');

    // Remove existing template classes
    preview.classList.remove('template-classic', 'template-modern');

    // Add new template class
    preview.classList.add(`template-${selector.value}`);
}

// PDF Generation
function downloadPDF() {
    const element = document.getElementById('resume-preview');
    const opt = {
        margin: 0,
        filename: `${document.getElementById('first-name').value || 'resume'}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
    };

    html2pdf().set(opt).from(element).save();
}

// Dynamic Sections Management
let expCount = 0;
let eduCount = 0;
let projCount = 0;
let certCount = 0;

function addExperience(data = null) {
    expCount++;
    const id = expCount;
    const list = document.getElementById('experience-list');

    const html = `
        <div class="dynamic-item" id="exp-form-${id}">
            <button type="button" class="remove-btn" onclick="removeSection('exp-form-${id}', 'preview-exp-${id}')">&times;</button>
            <div class="form-row">
                <div class="form-group">
                    <label>Job Title</label>
                    <input type="text" id="exp-title-${id}" oninput="updateExp(${id})" value="${data ? data.title : ''}">
                </div>
                <div class="form-group">
                    <label>Company</label>
                    <input type="text" id="exp-company-${id}" oninput="updateExp(${id})" value="${data ? data.company : ''}">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Start Date</label>
                    <input type="text" id="exp-start-${id}" placeholder="MM/YYYY" oninput="updateExp(${id})" value="${data ? data.start : ''}">
                </div>
                <div class="form-group">
                    <label>End Date</label>
                    <input type="text" id="exp-end-${id}" placeholder="Present or MM/YYYY" oninput="updateExp(${id})" value="${data ? data.end : ''}">
                </div>
            </div>
            <div class="form-group">
                <label>Description (bullet points separated by new lines)</label>
                <textarea id="exp-desc-${id}" rows="4" oninput="updateExp(${id})">${data ? data.desc : ''}</textarea>
            </div>
        </div>
    `;
    list.insertAdjacentHTML('beforeend', html);

    // Create preview mirror
    const previewList = document.getElementById('preview-experience-list');
    const previewHtml = `
        <div class="preview-item" id="preview-exp-${id}">
            <div class="item-header">
                <span id="p-exp-title-${id}">${data ? data.title : 'Job Title'}</span>
                <span id="p-exp-dates-${id}">${data ? data.start : 'Start Date'} - ${data ? data.end : 'End Date'}</span>
            </div>
            <div class="item-sub" id="p-exp-company-${id}">${data ? data.company : 'Company Name'}</div>
            <ul id="p-exp-desc-${id}">${formatBullets(data ? data.desc : '')}</ul>
        </div>
    `;
    previewList.insertAdjacentHTML('beforeend', previewHtml);
}

function updateExp(id) {
    document.getElementById(`p-exp-title-${id}`).textContent = document.getElementById(`exp-title-${id}`).value;
    document.getElementById(`p-exp-company-${id}`).textContent = document.getElementById(`exp-company-${id}`).value;
    document.getElementById(`p-exp-dates-${id}`).textContent = `${document.getElementById(`exp-start-${id}`).value} - ${document.getElementById(`exp-end-${id}`).value}`;
    document.getElementById(`p-exp-desc-${id}`).innerHTML = formatBullets(document.getElementById(`exp-desc-${id}`).value);
}

function addEducation(data = null) {
    eduCount++;
    const id = eduCount;
    const list = document.getElementById('education-list');

    const html = `
        <div class="dynamic-item" id="edu-form-${id}">
            <button type="button" class="remove-btn" onclick="removeSection('edu-form-${id}', 'preview-edu-${id}')">&times;</button>
            <div class="form-row">
                <div class="form-group">
                    <label>Degree</label>
                    <input type="text" id="edu-degree-${id}" oninput="updateEdu(${id})" value="${data ? data.degree : ''}">
                </div>
                <div class="form-group">
                    <label>School/University</label>
                    <input type="text" id="edu-school-${id}" oninput="updateEdu(${id})" value="${data ? data.school : ''}">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Graduation Year</label>
                    <input type="text" id="edu-year-${id}" oninput="updateEdu(${id})" value="${data ? data.year : ''}">
                </div>
                <div class="form-group">
                    <label>GPA (Optional)</label>
                    <input type="text" id="edu-gpa-${id}" oninput="updateEdu(${id})" value="${data ? data.gpa : ''}">
                </div>
            </div>
        </div>
    `;
    list.insertAdjacentHTML('beforeend', html);

    // Create preview mirror
    const previewList = document.getElementById('preview-education-list');
    const previewHtml = `
        <div class="preview-item" id="preview-edu-${id}">
            <div class="item-header">
                <span id="p-edu-school-${id}">${data ? data.school : 'School Name'}</span>
                <span id="p-edu-year-${id}">${data ? data.year : 'Year'}</span>
            </div>
            <div class="item-sub">
                <span id="p-edu-degree-${id}">${data ? data.degree : 'Degree Name'}</span>
                <span id="p-edu-gpa-container-${id}" style="${data && data.gpa ? '' : 'display:none'}">GPA: <span id="p-edu-gpa-${id}">${data ? data.gpa : ''}</span></span>
            </div>
        </div>
    `;
    previewList.insertAdjacentHTML('beforeend', previewHtml);
}

function updateEdu(id) {
    document.getElementById(`p-edu-degree-${id}`).textContent = document.getElementById(`edu-degree-${id}`).value;
    document.getElementById(`p-edu-school-${id}`).textContent = document.getElementById(`edu-school-${id}`).value;
    document.getElementById(`p-edu-year-${id}`).textContent = document.getElementById(`edu-year-${id}`).value;

    const gpa = document.getElementById(`edu-gpa-${id}`).value;
    document.getElementById(`p-edu-gpa-${id}`).textContent = gpa;
    document.getElementById(`p-edu-gpa-container-${id}`).style.display = gpa ? 'inline' : 'none';
}

function addProject(data = null) {
    projCount++;
    const id = projCount;
    const list = document.getElementById('project-list');

    const html = `
        <div class="dynamic-item" id="proj-form-${id}">
            <button type="button" class="remove-btn" onclick="removeSection('proj-form-${id}', 'preview-proj-${id}')">&times;</button>
            <div class="form-row">
                <div class="form-group">
                    <label>Project Name</label>
                    <input type="text" id="proj-name-${id}" oninput="updateProj(${id})" value="${data ? data.name : ''}">
                </div>
                <div class="form-group">
                    <label>Technologies Used</label>
                    <input type="text" id="proj-tech-${id}" oninput="updateProj(${id})" value="${data ? data.tech : ''}">
                </div>
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea id="proj-desc-${id}" rows="2" oninput="updateProj(${id})">${data ? data.desc : ''}</textarea>
            </div>
        </div>
    `;
    list.insertAdjacentHTML('beforeend', html);

    // Ensure preview projects section is visible
    document.getElementById('projects-section-preview').style.display = 'block';

    // Create preview mirror
    const previewList = document.getElementById('preview-project-list');
    const previewHtml = `
        <div class="preview-item" id="preview-proj-${id}">
            <div class="item-header">
                <span id="p-proj-name-${id}">${data ? data.name : 'Project Name'}</span>
                <span id="p-proj-tech-${id}" style="font-weight: normal; font-style: italic;">${data ? data.tech : 'Technologies'}</span>
            </div>
            <p id="p-proj-desc-${id}">${data ? data.desc : 'Project Description'}</p>
        </div>
    `;
    previewList.insertAdjacentHTML('beforeend', previewHtml);
}

function updateProj(id) {
    document.getElementById(`p-proj-name-${id}`).textContent = document.getElementById(`proj-name-${id}`).value;
    document.getElementById(`p-proj-tech-${id}`).textContent = document.getElementById(`proj-tech-${id}`).value;
    document.getElementById(`p-proj-desc-${id}`).textContent = document.getElementById(`proj-desc-${id}`).value;
}

function addCertification(data = null) {
    certCount++;
    const id = certCount;
    const list = document.getElementById('certifications-list');

    const html = `
        <div class="dynamic-item" id="cert-form-${id}">
            <button type="button" class="remove-btn" onclick="removeSection('cert-form-${id}', 'preview-cert-${id}')">&times;</button>
            <div class="form-row">
                <div class="form-group">
                    <label>Certification Name</label>
                    <input type="text" id="cert-name-${id}" oninput="updateCert(${id})" value="${data ? data.name : ''}">
                </div>
                <div class="form-group">
                    <label>Issuing Organization</label>
                    <input type="text" id="cert-org-${id}" oninput="updateCert(${id})" value="${data ? data.org : ''}">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Issue Date</label>
                    <input type="text" id="cert-date-${id}" placeholder="MM/YYYY" oninput="updateCert(${id})" value="${data ? data.date : ''}">
                </div>
                <div class="form-group">
                    <label>Expiration Date (Optional)</label>
                    <input type="text" id="cert-expiry-${id}" placeholder="MM/YYYY or Never" oninput="updateCert(${id})" value="${data ? data.expiry : ''}">
                </div>
            </div>
            <div class="form-group">
                <label>Credential ID (Optional)</label>
                <input type="text" id="cert-id-${id}" oninput="updateCert(${id})" value="${data ? data.id : ''}">
            </div>
        </div>
    `;
    list.insertAdjacentHTML('beforeend', html);

    // Create preview mirror
    const previewList = document.getElementById('preview-certifications-list');
    const previewHtml = `
        <div class="preview-item" id="preview-cert-${id}">
            <div class="item-header">
                <span id="p-cert-name-${id}">${data ? data.name : 'Certification Name'}</span>
                <span id="p-cert-date-${id}">${data ? data.date : 'Issue Date'}</span>
            </div>
            <div class="item-sub">
                <span id="p-cert-org-${id}">${data ? data.org : 'Issuing Organization'}</span>
                <span id="p-cert-expiry-container-${id}" style="${data && data.expiry ? '' : 'display:none'}"> • Expires: <span id="p-cert-expiry-${id}">${data ? data.expiry : ''}</span></span>
            </div>
            <div id="p-cert-id-container-${id}" style="${data && data.id ? '' : 'display:none'}">
                <span style="font-size: 10pt; color: #666;">Credential ID: <span id="p-cert-id-${id}">${data ? data.id : ''}</span></span>
            </div>
        </div>
    `;
    previewList.insertAdjacentHTML('beforeend', previewHtml);
}

function updateCert(id) {
    document.getElementById(`p-cert-name-${id}`).textContent = document.getElementById(`cert-name-${id}`).value;
    document.getElementById(`p-cert-org-${id}`).textContent = document.getElementById(`cert-org-${id}`).value;
    document.getElementById(`p-cert-date-${id}`).textContent = document.getElementById(`cert-date-${id}`).value;

    const expiry = document.getElementById(`cert-expiry-${id}`).value;
    document.getElementById(`p-cert-expiry-${id}`).textContent = expiry;
    document.getElementById(`p-cert-expiry-container-${id}`).style.display = expiry ? 'inline' : 'none';

    const certId = document.getElementById(`cert-id-${id}`).value;
    document.getElementById(`p-cert-id-${id}`).textContent = certId;
    document.getElementById(`p-cert-id-container-${id}`).style.display = certId ? 'block' : 'none';
}

function removeSection(formId, previewId) {
    document.getElementById(formId).remove();
    document.getElementById(previewId).remove();

    // Hide projects section if empty
    const projList = document.getElementById('preview-project-list');
    if (projList && projList.children.length === 0) {
        document.getElementById('projects-section-preview').style.display = 'none';
    }
}

function formatBullets(text) {
    if (!text) return '';
    return text.split('\n').filter(t => t.trim() !== '').map(t => `<li>${t}</li>`).join('');
}

// API Integration
function gatherFormData() {
    const data = {
        id: document.getElementById('resume-id').value,
        title: document.getElementById('doc-title').value,
        personal: {
            first_name: document.getElementById('first-name').value,
            last_name: document.getElementById('last-name').value,
            email: document.getElementById('email').value,
            phone: document.getElementById('phone').value,
            location: document.getElementById('location').value,
            linkedin: document.getElementById('linkedin').value,
            summary: document.getElementById('summary').value,
        },
        skills: document.getElementById('skills').value,
        experience: [],
        education: [],
        projects: []
    };

    // Gather Experience
    const expDivs = document.querySelectorAll('#experience-list .dynamic-item');
    expDivs.forEach(div => {
        const id = div.id.replace('exp-form-', '');
        data.experience.push({
            title: document.getElementById(`exp-title-${id}`).value,
            company: document.getElementById(`exp-company-${id}`).value,
            start: document.getElementById(`exp-start-${id}`).value,
            end: document.getElementById(`exp-end-${id}`).value,
            desc: document.getElementById(`exp-desc-${id}`).value
        });
    });

    // Gather Education
    const eduDivs = document.querySelectorAll('#education-list .dynamic-item');
    eduDivs.forEach(div => {
        const id = div.id.replace('edu-form-', '');
        data.education.push({
            degree: document.getElementById(`edu-degree-${id}`).value,
            school: document.getElementById(`edu-school-${id}`).value,
            year: document.getElementById(`edu-year-${id}`).value,
            gpa: document.getElementById(`edu-gpa-${id}`).value
        });
    });

    // Gather Projects
    const projDivs = document.querySelectorAll('#project-list .dynamic-item');
    projDivs.forEach(div => {
        const id = div.id.replace('proj-form-', '');
        data.projects.push({
            name: document.getElementById(`proj-name-${id}`).value,
            tech: document.getElementById(`proj-tech-${id}`).value,
            desc: document.getElementById(`proj-desc-${id}`).value
        });
    });

    return data;
}

function saveResume() {
    const data = gatherFormData();
    if (!data.title) {
        alert("Please provide a Document Title before saving.");
        return;
    }

    fetch('/api/resume', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                document.getElementById('resume-id').value = result.id;
                // Update URL without reloading to reflect new ID
                window.history.replaceState({}, '', `/builder/${result.id}`);
                alert('Resume saved successfully!');
            }
        })
        .catch(error => {
            console.error('Error saving resume:', error);
            alert('Failed to save resume. Please try again.');
        });
}

function loadResumeData(id) {
    fetch(`/api/resume/${id}`)
        .then(response => response.json())
        .then(result => {
            const data = result.data;

            document.getElementById('doc-title').value = result.title;

            // Load Personal Info
            if (data.personal) {
                document.getElementById('first-name').value = data.personal.first_name || '';
                document.getElementById('last-name').value = data.personal.last_name || '';
                document.getElementById('email').value = data.personal.email || '';
                document.getElementById('phone').value = data.personal.phone || '';
                document.getElementById('location').value = data.personal.location || '';
                document.getElementById('linkedin').value = data.personal.linkedin || '';
                document.getElementById('summary').value = data.personal.summary || '';

                // Trigger sync
                document.querySelectorAll('.sync-input').forEach(input => {
                    input.dispatchEvent(new Event('input'));
                });
            }

            if (data.skills) {
                document.getElementById('skills').value = data.skills;
                document.getElementById('skills').dispatchEvent(new Event('input'));
            }

            // Load Arrays
            if (data.experience && data.experience.length > 0) {
                data.experience.forEach(exp => addExperience(exp));
            } else {
                addExperience();
            }

            if (data.education && data.education.length > 0) {
                data.education.forEach(edu => addEducation(edu));
            } else {
                addEducation();
            }

            if (data.projects && data.projects.length > 0) {
                data.projects.forEach(proj => addProject(proj));
            }
        })
        .catch(error => console.error('Error loading resume:', error));
}

// ==========================================
// Chatbot Logic
// ==========================================
function toggleChat() {
    const window = document.getElementById('chatbot-window');
    window.classList.toggle('open');
}

function handleChatKeyPress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

function sendMessage() {
    const inputField = document.getElementById('chat-input-field');
    const message = inputField.value.trim();
    if (!message) return;

    // Add user message to UI
    appendChatMessage(message, 'user');
    inputField.value = '';

    // Send to backend
    fetch('/api/chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message: message })
    })
        .then(response => response.json())
        .then(data => {
            appendChatMessage(data.response, 'bot');
        })
        .catch(error => {
            console.error('Chat error:', error);
            appendChatMessage("Sorry, I'm having trouble connecting to the server.", 'bot');
        });
}

function appendChatMessage(text, sender) {
    const chatMessages = document.getElementById('chat-messages');
    const msgDiv = document.createElement('div');
    msgDiv.className = `chat-msg ${sender}`;
    msgDiv.textContent = text;
    chatMessages.appendChild(msgDiv);

    // Scroll to bottom
    chatMessages.scrollTop = chatMessages.scrollHeight;
}
